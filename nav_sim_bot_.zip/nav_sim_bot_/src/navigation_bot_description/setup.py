from setuptools import setup
import os
from glob import glob

package_name = 'navigation_bot_description'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
        (os.path.join('share', package_name, 'urdf'), glob('urdf/*')),
        (os.path.join('share', package_name, 'meshes'), glob('meshes/*')),
        (os.path.join('share', package_name, 'config'), glob('config/*'))
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Your Name',
    maintainer_email='your.email@example.com',
    description='The ' + package_name + ' package for URDF export from Fusion 360 to ROS2',
    license='MIT',  # Example license
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            # Example if you have any executables to run
             'initial_pose = navigation_bot_description.initial_pose:main',
        ],
    },
)
